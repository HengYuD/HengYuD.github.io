#!/bin/bash
sudo /OpenBTS/OpenBTSCLI

